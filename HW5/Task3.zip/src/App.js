import './App.css';
import React from 'react';

function App() {
  return (
    <Projects />
  );
}

class Projects extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      value: null,
      projects: Array(3).fill(null),
    };
  }

  renderProject(i){
    return(<Project 
      number={i}
    />);
  }

  render() {
    return(
      <div className='project-list'> <h3>Project List</h3>
        <div className='project-box'>
          {this.renderProject(1)}
        </div>
        <div className='project-box'>
          {this.renderProject(2)}
        </div>
        <div className='project-box'>
          {this.renderProject(3)}
        </div>
      </div>
    );
  }
}

  

class Project extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      number: props.number,
      hw1: 0,
      hw2: 0,
    };
  }
  render() {
    return(
      <div className="project">
        <div className='project-name'>Project {this.state.number}</div>
        <div className='hwset1'>HWSet1: {this.state.hw1}/100
        <button className='button' onClick={() => this.setState({hw1: this.state.hw1+1,})}>Check Out</button>
        <button className='button' onClick={() => this.setState({hw1: this.state.hw1-1,})}>Check In</button>
        </div>
        <div className='hwset2'>HWSet2: {this.state.hw2}/100 
        <button className='button' onClick={() => this.setState({hw2: this.state.hw2+1,})}>Check Out</button>
        <button className='button' onClick={() => this.setState({hw2: this.state.hw2-1,})}>Check In</button>
        </div>
        
      </div>
        
    );
  }
}


export default App;
