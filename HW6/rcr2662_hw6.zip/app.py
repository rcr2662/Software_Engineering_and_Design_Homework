from flask import Flask, render_template
from flask import flash

app = Flask(__name__)
app.secret_key = b'123456789'
@app.route("/")
def home():
    return "Welcome!"


@app.route("/checkin/<projectID>/<qty>")
def checkIn_hardware(projectID, qty):
    flash(qty + " hardware checked in")
    return render_template(
        "frontend.html",
        projectID=projectID,
        qty=qty
    )

@app.route("/checkout/<projectID>/<qty>")
def checkOut_hardware(projectID, qty):
    flash(qty + " hardware checked out")
    return render_template(
        "frontend.html",
        projectID=projectID,
        qty=qty
    )

@app.route("/join/<projectID>")
def joinProject(projectID):
    flash("Joined " + projectID)
    return render_template(
        "frontend.html",
        projectID=projectID,
    )

@app.route("/leave/<projectID>")
def leaveProject(projectID):
    flash("Left " + projectID)
    return render_template(
        "frontend.html",
        projectID=projectID,
    )

if __name__ == "__main__":
    app.run(host='0.0.0.0', debug=False, port=os.environ.get('PORT', 80))